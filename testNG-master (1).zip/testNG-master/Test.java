package dataDriven;

public @interface Test {

}
